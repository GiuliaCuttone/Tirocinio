#K-Folds Cross Validation con kmers plot

from sklearn import svm                               #per creare il vettore
from sklearn.model_selection import StratifiedKFold   #KFold

#accuracy, precision, recall, MCC
from sklearn.metrics import accuracy_score, precision_score, recall_score, matthews_corrcoef

#per la matrice di confusione
from sklearn.metrics import confusion_matrix

import pandas as pd
import numpy as np

import matplotlib.pyplot as plt                       #plot accuracy


def dati(dataset):    
    Classe = np.array(dataset['Classe'])            #output
    
    new_dataset = dataset.set_index('Classe')
    Dati = np.array(new_dataset)                    #input

    return Dati, Classe
    

def calcola(X, y, Acc, Pr, Rc, Matt):
    Accuracy = 0
    Precision = 0
    Recall = 0
    Matthew = 0
    CM = np.zeros((13, 13))
    
    for train_index, test_index in kf.split(X, y):
        #separa le variabili per l'addestramento da quelle per il test
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
    
        clf.fit(X_train, y_train)
        pred = clf.predict(X_test)
        
        cm = confusion_matrix(y_test, pred)
        CM += cm
    
        score = accuracy_score(y_test, pred)*100     
        precision = precision_score(y_test, pred, average='weighted')*100
        recall = recall_score(y_test, pred, average='weighted')*100
        
        MCC = matthews_corrcoef(y_test, pred)
        
        Accuracy += score
        Precision += precision
        Recall += recall
        
        Matthew += MCC
    
    Accuracy = Accuracy/nfold
    Acc.append(Accuracy)
    
    Precision = Precision/nfold
    Pr.append(Precision)
    
    Recall = Recall/nfold
    Rc.append(Recall)
    
    Matthew = Matthew/nfold
    Matt.append(Matthew)
    
    return Acc, Pr, Rc, Matt, CM
         
    

Acc = []        #medie Accuracy
Pr = []         #medie Precision
Rc = []         #medie Recall
Matt = []       #medie MCC score

kmers = list(range(3, 8))    #numero di kmer 
nfold = 5

#carica il dataset   
for k in kmers:
    filename = ('%sKmer.csv' %k)
    data = pd.read_csv(filename, index_col='Nome')      #carica dataset da file csv
        
    X, y = dati(data)

    clf = svm.SVC(kernel='linear', C=1)         #SVM
    kf = StratifiedKFold(n_splits=nfold)        #K-Folds

    Acc, Pr, Rc, Matt, CM = calcola(X, y, Acc, Pr, Rc, Matt)
    
    print("K = %s" %k)
    
    plt.matshow(CM) 
    plt.title('Matrice di confusione\n') 
    plt.colorbar() 
    plt.show() 
    
    
fig, (ax0, ax1) = plt.subplots(1, 2, sharey='row')
fig, ax2 = plt.subplots()

ax0.set(xlabel='Kmers', ylabel='Accuracy')
ax1.set(xlabel='Kmers', ylabel='Precision & Recall')
ax2.set(xlabel='Kmers', ylabel='MCC coefficient')

ax0.plot(kmers, Acc, "blue", label="Accuracy")        #accuracy
ax1.plot(kmers, Pr, "lightgreen", label="Precision")  #precision
ax1.plot(kmers, Rc, "orange", label="Recall")         #recall
ax2.plot(kmers, Matt, "yellow", kmers, Matt, "*b")    #mcc

ax0.legend(loc='best')
ax1.legend(loc='best')
ax2.legend(['Matthew coefficient'])

plt.show()
    