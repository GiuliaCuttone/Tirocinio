#4^k kmer

#Combinazioni
def combinaric(lst, set, curr, n, k):
    for i in range(0, len(set)):
        loccurr = curr + set[i]
        
        if k==1:
            lst.append(loccurr)
        else:
            combinaric(lst, set[:], loccurr, n-1, k-1)

def combina(set, k):
    lst = []
    n = len(set)
    combinaric( lst, set, "", n, k )
    return lst


def Kmer(k):
    with open("Dataset.fasta", 'r') as f:
        seq = ""          #sequenza
        key = ""          #nome sequenza
    
        for line in f.readlines():
            if line.startswith(">"):         #nuova sequenza
                if key and seq:
                    printSeq(key, seq, k)       #stampa il risultato delle sequenze
                key = line[1:].split(" ")       #memorizza il nome dopo '>'
                seq = ""                     #resetta la sequenza
            else:
                seq += line.strip()          #prende la sequenza fin quando non incontriamo '>'
        printSeq(key, seq, k)       #stampa il risultato dell'ultima sequenza
    
    f.close()     #chiude file
    

def printSeq(name, seq, k):
    final.write("%s" %name + "\n")     #stampa il nome della sequenza corrente
    
    countkmers = {}                    #vettore di sottosequenze
    
    for i in range(len(seq) - k + 1):
        kmer = seq[i:i+k]
        if kmer in countkmers:
            countkmers[kmer] += 1        #incrementa il contatore della sottosequenza corrispondente
        else:
            countkmers[kmer] = 1        #inizializza il contatore di sottosequenza corrispondente a 1 

    sortedKmer = sorted(countkmers.items())    #ordina le sottosequenze

    for kmer, count in sortedKmer:
        final.write(kmer + "\t" + str(count) + "\n")

    

#Crea dei nuovi file con 4, 5 e 6 Kmer
for k in range(4, 7):  #lunghezza sottosequenza (K-mer)
    final = open("DatasetFinale%sKmer.fasta" %k, "w")    #file di output
    
    Kmer(k)
    
    final.close()    #chiude file