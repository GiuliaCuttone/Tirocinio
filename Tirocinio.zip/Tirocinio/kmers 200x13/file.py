def printSeq(name, seq, sequences):
    classe = name.split(" ")
    classe = classe[1]
    
    if classe in sequences:
        if sequences[classe] < 200:
            sequences[classe] += 1
            final.write("%s" %name + "\n")     #stampa il nome della sequenza corrente
            final.write(seq + "\n")
        else: return
    else:
        sequences[classe] = 1
        final.write("%s" %name + "\n")     #stampa il nome della sequenza corrente
        final.write(seq + "\n")

       
        
final = open("Dataset.fasta", "w")    #file di output

with open("dataset_Rfam_6320_13classes.fasta", 'r') as f:
    seq = ""          #sequenza
    key = ""          #nome sequenza
    sequences = {}                  #vettore di sequenze
    
    for line in f.readlines():
        
        if line.startswith(">"):         #nuova sequenza
            if key and seq:
                printSeq(key, seq, sequences)       #stampa il risultato delle sequenze
            key = line.strip()           #memorizza il nome
            seq = ""                     #resetta la sequenza
            
        else:
            seq += line.strip()          #prende la sequenza fin quando non incontriamo '>'
    printSeq(key, seq, sequences)       #stampa il risultato dell'ultima sequenza
    
f.close()
final.close()