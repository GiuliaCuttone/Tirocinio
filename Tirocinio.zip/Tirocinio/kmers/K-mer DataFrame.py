#4^k kmer

import pandas as pd

#Combinazioni
def combina(set, k):
    lst = []
    n = len(set)
    combinaric( lst, set, "", n, k )
    return lst

def combinaric(lst, set, curr, n, k):
    for i in range(0, len(set)):
        loccurr = curr + set[i]
        
        if k==1:
            lst.append(loccurr)
        else:
            combinaric(lst, set[:], loccurr, n-1, k-1)
            

def Kmer(k, lst, df):
    with open("dataset_Rfam_6320_13classes.fasta", 'r') as f:
        ind = 0           #indice riga
        Nome = []         #array nomi
        Classe = []       #array classi
        seq = ""          #sequenza
        key = ""          #nome sequenza
    
        for line in f.readlines():
            if line.startswith(">"):         #nuova sequenza
                if key and seq:
                    printSeq(key, seq, k, lst, Nome, Classe, ind, df)       #stampa il risultato delle sequenze
                    ind = ind + 1
                key = line[1:].split(" ")       #memorizza il nome dopo '>'
                seq = ""                        #resetta la sequenza
            else:
                seq += line.strip()            #prende la sequenza fin quando non incontriamo '>'
        printSeq(key, seq, k, lst, Nome, Classe, ind, df)       #stampa il risultato dell'ultima sequenza
        ind = ind + 1
    
    df["Nome"] = Nome           #incolonna i nomi nel dataframe
    df["Classe"] = Classe       #incolonna le classi nel dataframe
    
    df = df.fillna(0)                #sostituisce i valori nulli con 0
    df = df.set_index('Nome')        #setta l'indice con i nomi delle sequenze
    
    print(df)
    
    filename = ('%sKmer.csv' %k)
    df.to_csv(filename, index=True)      #salva il dataframe in un file csv
    
    f.close()     #chiude file
        

def printSeq(name, seq, k, kmers, Nome, Classe, ind, df):
    Nome.append(name[0])               #aggiunge il nome corrente
    Classe.append(name[1])             #aggiunge la classe corrente
    
    countkmers = {}                    #vettore di sottosequenze
    
    for i in range(len(seq) - k + 1):
        kmer = seq[i:i+k]
        if kmer in countkmers:
            countkmers[kmer] += 1        #incrementa il contatore della sottosequenza corrispondente
        else:
            countkmers[kmer] = 1        #inizializza il contatore di sottosequenza corrispondente a 1 

    sortedKmer = sorted(countkmers.items())    #ordina le sottosequenze

    for kmer, count in sortedKmer:
        for x in df.columns:
            if kmer == x:
                df.at[ind, x] = count    #colloca il numero di sottosequenze contate nella sottosequenza corrispondente
                continue



#Crea dei nuovi file con 3, 4, 5, 6 e 7 Kmer
for k in range(3, 8):               #lunghezza sottosequenza (K-mer)
    lst = combina("ACGT", k)        #combinazioni sottosequenza
    
    feature = ['Nome']
    
    for i in range(0, len(lst)):
        s = str(lst[i])
        feature.append(s)

    feature.append('Classe')

    df = pd.DataFrame(columns=(feature), index=range(0, 6320))   #crea dataframe vuoto
        
    Kmer(k, lst, df)